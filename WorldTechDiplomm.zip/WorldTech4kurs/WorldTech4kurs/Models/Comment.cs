﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class Comment
{
    public int IdComment { get; set; }

    public string CommentText { get; set; } = null!;

    public DateTime DateComm { get; set; }

    public int? IdProduct { get; set; }

    public int? IdUserCom { get; set; }

    public virtual User? IdUserComNavigation { get; set; }
}
