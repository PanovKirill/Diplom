﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WorldTech4kurs.Models;

public partial class A0982169Diplom123Context : DbContext
{
    public A0982169Diplom123Context()
    {
    }

    public A0982169Diplom123Context(DbContextOptions<A0982169Diplom123Context> options)
        : base(options)
    {
    }

    public virtual DbSet<CartDetail> CartDetails { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Comment> Comments { get; set; }

    public virtual DbSet<EfmigrationsHistory> EfmigrationsHistories { get; set; }

    public virtual DbSet<OrderListUser> OrderListUsers { get; set; }

    public virtual DbSet<OrderStatus> OrderStatuses { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<ShoppingCart> ShoppingCarts { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserOrder> UserOrders { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("data source=141.8.192.93;user=a0993816_Diplom123;password=Diplom123;initial catalog=a0993816_Diplom123", Microsoft.EntityFrameworkCore.ServerVersion.Parse("5.7.35-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8_general_ci")
            .HasCharSet("utf8");

        modelBuilder.Entity<CartDetail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("CartDetail");

            entity.HasIndex(e => e.UserId, "Id");

            entity.HasIndex(e => e.Price, "Price");

            entity.HasIndex(e => e.ProductId, "ProductId");

            entity.HasIndex(e => e.ShoppingCartId, "ShoppingCartId");

            entity.Property(e => e.Id)
                .HasColumnType("int(255)")
                .HasColumnName("id");
            entity.Property(e => e.ProductId).HasColumnType("int(255)");
            entity.Property(e => e.ProductName).HasColumnType("text");
            entity.Property(e => e.Quantity).HasColumnType("int(255)");
            entity.Property(e => e.ShoppingCartId).HasColumnType("int(255)");
            entity.Property(e => e.UserId).HasColumnType("int(255)");

            entity.HasOne(d => d.Product).WithMany(p => p.CartDetails)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("CartDetail_ibfk_1");

            entity.HasOne(d => d.User).WithMany(p => p.CartDetails)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("CartDetail_ibfk_3");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.IdCategory).HasName("PRIMARY");

            entity.ToTable("Category");

            entity.Property(e => e.IdCategory)
                .ValueGeneratedNever()
                .HasColumnType("int(255)");
            entity.Property(e => e.CategoryDescription).HasColumnType("text");
            entity.Property(e => e.CategoryName).HasColumnType("text");
        });

        modelBuilder.Entity<Comment>(entity =>
        {
            entity.HasKey(e => e.IdComment).HasName("PRIMARY");

            entity.UseCollation("utf8_unicode_ci");

            entity.HasIndex(e => e.IdUserCom, "IdUserCom");

            entity.Property(e => e.IdComment)
                .ValueGeneratedNever()
                .HasColumnType("int(255)");
            entity.Property(e => e.CommentText).HasColumnType("text");
            entity.Property(e => e.DateComm).HasColumnType("datetime");
            entity.Property(e => e.IdProduct).HasColumnType("int(255)");
            entity.Property(e => e.IdUserCom).HasColumnType("int(255)");

            entity.HasOne(d => d.IdUserComNavigation).WithMany(p => p.Comments)
                .HasForeignKey(d => d.IdUserCom)
                .HasConstraintName("Comments_ibfk_1");
        });

        modelBuilder.Entity<EfmigrationsHistory>(entity =>
        {
            entity.HasKey(e => e.MigrationId).HasName("PRIMARY");

            entity
                .ToTable("__EFMigrationsHistory")
                .HasCharSet("utf8mb4")
                .UseCollation("utf8mb4_general_ci");

            entity.Property(e => e.MigrationId).HasMaxLength(150);
            entity.Property(e => e.ProductVersion).HasMaxLength(32);
        });

        modelBuilder.Entity<OrderListUser>(entity =>
        {
            entity.HasKey(e => e.IdProduct).HasName("PRIMARY");

            entity.ToTable("OrderListUser");

            entity.Property(e => e.IdProduct)
                .ValueGeneratedNever()
                .HasColumnType("int(255)");
            entity.Property(e => e.IdOrderList).HasColumnType("int(255)");
            entity.Property(e => e.IdUser).HasColumnType("int(255)");
            entity.Property(e => e.IdUserOrder).HasColumnType("int(255)");
            entity.Property(e => e.ProductCount).HasColumnType("int(255)");
            entity.Property(e => e.ProductName).HasColumnType("text");
            entity.Property(e => e.ProductPrice).HasPrecision(10);
        });

        modelBuilder.Entity<OrderStatus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("OrderStatus");

            entity.HasIndex(e => e.StatusName, "StatusName");

            entity.Property(e => e.Id).HasColumnType("int(255)");
            entity.Property(e => e.StatusName).HasMaxLength(100);
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.IdProduct).HasName("PRIMARY");

            entity.ToTable("Product", tb => tb.HasComment("Products"));

            entity.HasIndex(e => e.IdCategory, "IdCategory");

            entity.HasIndex(e => e.ProductCount, "ProductCout");

            entity.Property(e => e.IdProduct)
                .ValueGeneratedNever()
                .HasColumnType("int(255)");
            entity.Property(e => e.CountryOfProduction).HasColumnType("text");
            entity.Property(e => e.IdCategory).HasColumnType("int(255)");
            entity.Property(e => e.Manufacturer).HasColumnType("text");
            entity.Property(e => e.ProductCount).HasColumnType("int(255)");
            entity.Property(e => e.ProductDescription).HasColumnType("text");
            entity.Property(e => e.ProductImage).HasColumnType("text");
            entity.Property(e => e.ProductName).HasColumnType("text");
            entity.Property(e => e.WarrantyPeriod).HasColumnType("int(255)");

            entity.HasOne(d => d.IdCategoryNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.IdCategory)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Product_ibfk_1");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.IdRoles).HasName("PRIMARY");

            entity.ToTable("Role");

            entity.Property(e => e.IdRoles).HasColumnType("int(255)");
            entity.Property(e => e.NameRole).HasColumnType("text");
        });

        modelBuilder.Entity<ShoppingCart>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("ShoppingCart");

            entity.HasIndex(e => e.IsDeleted, "IsDeleted");

            entity.HasIndex(e => e.UserId, "UserId");

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnType("int(255)");
            entity.Property(e => e.UserId).HasColumnType("int(255)");

            entity.HasOne(d => d.IdNavigation).WithOne(p => p.ShoppingCart)
                .HasForeignKey<ShoppingCart>(d => d.Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("ShoppingCart_ibfk_2");

            entity.HasOne(d => d.User).WithMany(p => p.ShoppingCarts)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("ShoppingCart_ibfk_1");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.IdUsers).HasName("PRIMARY");

            entity.ToTable("User");

            entity.HasIndex(e => e.IdCart, "IdCart");

            entity.HasIndex(e => e.IdRoles, "IdRoles");

            entity.Property(e => e.IdUsers).HasColumnType("int(255)");
            entity.Property(e => e.IdCart).HasColumnType("int(255)");
            entity.Property(e => e.IdRoles).HasColumnType("int(255)");
            entity.Property(e => e.UserEmail).HasColumnType("text");
            entity.Property(e => e.UserName).HasColumnType("text");
            entity.Property(e => e.UserPassword).HasColumnType("text");
            entity.Property(e => e.UserPhone).HasColumnType("text");

            entity.HasOne(d => d.IdRolesNavigation).WithMany(p => p.Users)
                .HasForeignKey(d => d.IdRoles)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("User_ibfk_1");
        });

        modelBuilder.Entity<UserOrder>(entity =>
        {
            entity.HasKey(e => e.UserOrderId).HasName("PRIMARY");

            entity.ToTable("UserOrder");

            entity.HasIndex(e => e.CreatTime, "CreatTime");

            entity.HasIndex(e => e.IsDeleted, "IsDeleted");

            entity.HasIndex(e => e.StatusId, "StatusId");

            entity.HasIndex(e => e.TotalPrice, "TotalPrice");

            entity.HasIndex(e => e.UserId, "UserId");

            entity.Property(e => e.UserOrderId).HasColumnType("int(255)");
            entity.Property(e => e.CreatTime).HasColumnType("datetime");
            entity.Property(e => e.StatusId).HasColumnType("int(255)");
            entity.Property(e => e.UserId).HasColumnType("int(255)");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
