﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class CartDetail
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public int ShoppingCartId { get; set; }

    public int ProductId { get; set; }

    public int Quantity { get; set; }

    public string ProductName { get; set; } = null!;

    public decimal Price { get; set; }

    public virtual Product Product { get; set; } = null!;

    public virtual ShoppingCart? ShoppingCart { get; set; }

    public virtual User User { get; set; } = null!;
}
