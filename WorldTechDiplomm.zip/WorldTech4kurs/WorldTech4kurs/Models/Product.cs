﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

/// <summary>
/// Products
/// </summary>
public partial class Product
{
    public int IdProduct { get; set; }

    public int IdCategory { get; set; }

    public string ProductName { get; set; } = null!;

    public string ProductDescription { get; set; } = null!;

    public decimal ProductPrice { get; set; }

    public string ProductImage { get; set; } = null!;

    public int ProductCount { get; set; }

    public string? Manufacturer { get; set; }

    public string? CountryOfProduction { get; set; }

    public int? WarrantyPeriod { get; set; }

    public virtual ICollection<CartDetail> CartDetails { get; set; } = new List<CartDetail>();

    public virtual Category IdCategoryNavigation { get; set; } = null!;
}
