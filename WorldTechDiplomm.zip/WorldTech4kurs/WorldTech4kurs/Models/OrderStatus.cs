﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class OrderStatus
{
    public int Id { get; set; }

    public string StatusName { get; set; } = null!;
}
