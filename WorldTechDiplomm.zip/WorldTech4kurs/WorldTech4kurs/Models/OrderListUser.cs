﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class OrderListUser
{
    public int IdOrderList { get; set; }

    public int IdUserOrder { get; set; }

    public int IdUser { get; set; }

    public int IdProduct { get; set; }

    public int ProductCount { get; set; }

    public string ProductName { get; set; } = null!;

    public decimal ProductPrice { get; set; }
}
