﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class User
{
    public int IdUsers { get; set; }

    public int IdCart { get; set; }

    public string UserName { get; set; } = null!;

    public string UserPassword { get; set; } = null!;

    public string? UserEmail { get; set; }

    public int IdRoles { get; set; }

    public string? UserPhone { get; set; }

    public virtual ICollection<CartDetail> CartDetails { get; set; } = new List<CartDetail>();

    public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();

    public virtual Role IdRolesNavigation { get; set; } = null!;

    public virtual ICollection<ShoppingCart> ShoppingCarts { get; set; } = new List<ShoppingCart>();
}
