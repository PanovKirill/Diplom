﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class UserOrder
{
    public int UserOrderId { get; set; }

    public int UserId { get; set; }

    public DateTime CreatTime { get; set; }

    public decimal TotalPrice { get; set; }

    public int StatusId { get; set; }

    public bool IsDeleted { get; set; }
}
