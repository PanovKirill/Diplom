﻿using System;
using System.Collections.Generic;

namespace WorldTech4kurs.Models;

public partial class ShoppingCart
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public bool IsDeleted { get; set; }

    public virtual CartDetail IdNavigation { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
