﻿using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class CartViewModel
    {
        public List<CartDetail> CartDetails  { get; set; }
        public List<Product> Products { get; set; }
        public List<User> Users { get; set; }

    }
}
