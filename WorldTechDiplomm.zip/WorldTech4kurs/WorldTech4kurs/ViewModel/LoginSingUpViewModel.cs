﻿using System.ComponentModel.DataAnnotations;
using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class LoginSingUpViewModel
    {
        
        public int IdUsers { get; set; }
        [Required]
        public string UserName { get; set; } = null!;
        [Required]
        public string UserPassword { get; set; } = null!;
        [Required]
        public string ConfirmPassword { get; set; } = null!;
        [Required]
        public string UserEmail { get; set; } = null!;
        [Required]
        public string UserPhone { get; set; } = null!;

        public int IdRoles { get; set; }
        public virtual Role IdRolesNavigation { get; set; } = null!;
    }
}
