﻿using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class UserOrderViewModel
    {
        public List<UserOrder> UserOrders { get; set; }
    }
}
