﻿using Microsoft.AspNetCore.Mvc.Rendering;
using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class ProductsViewModel
    {
        public List<Product> Products {  get; set; }
        public List<Category> Categories { get; set;}
        //public List<Category> Categories {  get; set; }

        public int SelectedCategory { get; set; } = 0;
        public int SelectedSorting { get; set; } = 0;
        public List<SelectListItem> CategoriesSelected
        {
            get
            {
                List<SelectListItem> result = new();
                foreach (var category in Categories)
                {
                    var item = new SelectListItem
                    {
                        Value = category.IdCategory.ToString(),
                        Text = category.CategoryName,
                        Selected = category.IdCategory == SelectedCategory ? true : false,
                    };
                    result.Add(item);
                }
                return result;
            }
        }
    }
}
