﻿using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class OrderViewModel
    {
        public List<UserOrder> UserOrders { get; set; }
        public List<CartDetail> CartDetails { get; set; }
    }
}
