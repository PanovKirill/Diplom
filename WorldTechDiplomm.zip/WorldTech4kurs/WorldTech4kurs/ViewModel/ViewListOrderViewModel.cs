﻿using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class ViewListOrderViewModel
    {
        public List<OrderListUser> listUsers { get; set; }
    }
}
