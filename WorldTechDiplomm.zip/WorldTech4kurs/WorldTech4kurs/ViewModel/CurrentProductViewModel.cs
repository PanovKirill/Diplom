﻿using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class CurrentProductViewModel
    {
        public List<Product> Products { get; set; }
        public List<Comment> Comments { get; set; }
        public List<User> Users{ get; set; }
    }
}
