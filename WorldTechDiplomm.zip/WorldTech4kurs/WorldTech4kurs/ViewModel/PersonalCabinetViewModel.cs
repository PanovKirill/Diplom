﻿using WorldTech4kurs.Models;

namespace WorldTech4kurs.ViewModel
{
    public class PersonalCabinetViewModel
    {
        public List<User> Userss = new List<User>();
        public List<UserOrder> UserOrders { get; set; }
    }
}
