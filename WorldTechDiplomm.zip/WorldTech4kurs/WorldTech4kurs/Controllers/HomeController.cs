﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Diagnostics;
using WorldTech4kurs.Models;
using WorldTech4kurs.ViewModel;

namespace WorldTech4kurs.Controllers
{
    //[Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly A0982169Diplom123Context _context;
        public HomeController(ILogger<HomeController> logger, A0982169Diplom123Context context)
        {
            _context = context;
            _logger = logger;
        }



        public IActionResult Index()
        {
            var products = new List<Product>();
            return View(new ProductsViewModel { Products = products });
        }
        [HttpGet]
        public IActionResult EditProduct(int? IdProduct, Product model)
        {
            if (IdProduct == null)
            {
                TempData["errorMessage"] = "Имя пользователя или пароль не найдено";
                return View(model);
            }
            var product = _context.Products.Find(IdProduct);
            if (product != null)
            {
                return View(product);
            }
            return View(model);

        }
        [HttpPost]
        public IActionResult EditProduct(Product product)
        {
            Random random = new Random();
            int randomIdProduct = random.Next(4, 1234567890);
            product.IdProduct = randomIdProduct;
            if (product == null)
            {
                TempData["erroradd"] = "Ошибка при добавление товара";
                RedirectToAction("Index", "Home");
            }
            if (product.IdCategory > 2 || product.IdCategory < 0)
            {
                TempData["erroradd"] = "Ошибка при добавление товара";
                return RedirectToAction("Index");
            }
            if (product.IdCategory == 0)
            {
                TempData["erroradd"] = "Ошибка при добавление товара";
                return RedirectToAction("Index");
            }
            if (product.ProductName == null)
            {
                TempData["erroradd"] = "Ошибка при добавление товара";
                return RedirectToAction("Index");
            }
            if (product.ProductDescription == null)
            {
                TempData["erroradd"] = "Ошибка при добавление товара";
                return RedirectToAction("Index");
            }
            if (product.ProductImage == null)
            {
                TempData["erroradd"] = "Ошибка при добавление товара";
                return RedirectToAction("Index");
            }



            _context.Add(product);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult CurrentProduct(int ProductId)
        {
            var currentcomment = _context.Comments.Where(c => c.IdProduct == ProductId).ToList();
            var currentproduct = _context.Products.FirstOrDefault(p => p.IdProduct == ProductId);
            List<Product> products = new List<Product>
            {
                currentproduct
            };


            return View(new CurrentProductViewModel { Products = products, Comments = currentcomment });
        }


        public IActionResult Products(string? name, int categoryId, int sortType)
        {

            var products = _context.Products.ToList();
            var category = _context.Categories.ToList();
            if (categoryId == 0)
            {
                if (name == null)
                {
                    products = _context.Products.ToList();
                }
                else
                {
                    products = _context.Products.Where(p => p.ProductName.Contains(name ?? string.Empty)).ToList();
                }
            }
            else if (categoryId == 1)
            {
                products = _context.Products.Where(p => p.IdCategory == categoryId).Where(p => p.ProductName.Contains(name ?? string.Empty)).ToList();
            }
            else
            {
                products = _context.Products.Where(p => p.IdCategory == categoryId).Where(p => p.ProductName.Contains(name ?? string.Empty)).ToList();
            }

            if (sortType == 1)
            {
                var sorted = products.OrderBy(p => p.ProductPrice);
                products = sorted.ToList();
            }
            else if (sortType == 2)
            {
                var sorted = products.OrderByDescending(p => p.ProductPrice);
                products = sorted.ToList();
            }
            else
            {

            }
            return View(new ProductsViewModel { Products = products, Categories = category, SelectedCategory = categoryId, SelectedSorting = sortType });
        }

        public IActionResult Privacy()
        {
            return RedirectToAction("Products", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpPost]
        public IActionResult AddComment(int productId, string? Com, int UserId)
        {
            string[] forbiddenWords = { "бля", "сука", "пиздец", "нахуй", "негр", "сук", "бл", "пизд", "негры", "нах", "бла", "сус", "курдюк", "пидор", "пидоры" };
            var dateTime = DateTime.Now;

            if (Com == null)
            {
                TempData["errorMessage"] = "Ваш комментарий пустой.";
                return RedirectToAction("CurrentProduct", new { ProductId = productId });
            }

            // Проверяем, содержит ли комментарий запрещенные слова
            bool containsForbiddenWords = forbiddenWords.Any(word => Com.Contains(word, StringComparison.OrdinalIgnoreCase));

            // Если комментарий содержит запрещенные слова, возвращаем ошибку
            if (containsForbiddenWords)
            {
                TempData["errorMessage"] = "Ваш комментарий содержит запрещенные слова.";
                return RedirectToAction("CurrentProduct", new { ProductId = productId });
            }



            Random rnd = new Random();
            var currentproduct = _context.Products.FirstOrDefault(p => p.IdProduct == productId);
            var Item = new Comment
            {
                CommentText = Com.Trim(),
                IdComment = rnd.Next(0, 9999999),
                IdProduct = productId,
                IdUserCom = 1,
                DateComm = dateTime,

            };
            _context.Comments.Add(Item);
            _context.SaveChanges();
            TempData["successAcceptMessage"] = "Подтверждение произошло успешно";
            return RedirectToAction("CurrentProduct", new { ProductId = productId });
        }

        public ActionResult AddProductJson()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddProductJson(IFormFile jsonfile)
        {
            if (jsonfile != null && jsonfile.Length > 0)
            {
                // Читаем JSON файл из загруженного файла
                using (var reader = new StreamReader(jsonfile.OpenReadStream()))
                {
                    string jsonContent = await reader.ReadToEndAsync();

                    // Десериализуем JSON в объект Product
                    var product = JsonConvert.DeserializeObject<Product>(jsonContent);

                    var uss = _context.Products.FirstOrDefault(u => u.IdProduct == product.IdProduct);
                    if (uss != null)
                    {
                        return View();
                    }
                    else
                    {
                        _context.Add(product);
                        _context.SaveChanges();
                    }



                    return RedirectToAction("Products");
                }
            }
            return View();



        }
    }
}
