﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Session;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using WorldTech4kurs.Models;
using WorldTech4kurs.ViewModel;
namespace WorldTech4kurs.Controllers
{
    public class CartController : Controller
    {
        A0982169Diplom123Context _Context;

        public CartController(A0982169Diplom123Context Context)
        {
            _Context = Context;
        }
        [Authorize]
        public IActionResult Cart(int UserId)
        {
            var products = _Context.Products.ToList();
            var users = _Context.Users.ToList();
            //var Cartl = _Context.CartDetails.ToList();

            var usersss = User.Identity.Name;
            var uss = _Context.Users.FirstOrDefault(u => u.UserName == usersss);
            UserId = uss.IdUsers;
            var Cartl = _Context.CartDetails.Where(cd => cd.UserId == UserId).ToList();        
            return View(new CartViewModel { CartDetails = Cartl, Products = products, Users = users});
            
        }
        [Authorize]
        public IActionResult AddToCart(int productId, int UserId)
        {
            var users = User.Identity.Name;
            var uss = _Context.Users.FirstOrDefault(u => u.UserName == users);
            UserId = uss.IdUsers;
            var Cartl = _Context.CartDetails.FirstOrDefault(p => p.ProductId == productId);            
            int count = 1;
            Random rnd = new Random();           
            var user = _Context.Users.FirstOrDefault(u => u.IdUsers == UserId);
            var product = _Context.Products.FirstOrDefault(p => p.IdProduct == productId);
            
            //Создание объекта
            //var newItem = new CartDetail { UserId = UserId ,ProductName = product.ProductName ,Id = rnd.Next(0,1000000000), ProductId = product.IdProduct, Price = product.ProductPrice, Quantity = 1 };
            //var newItem = new CartDetail { UserId = UserId, ProductName = product.ProductName, Id = rnd.Next(0, 1000000000), ProductId = product.IdProduct, Price = product.ProductPrice, Quantity = count };



            //Добавление в бд
            //var existingItem = _Context.Products.FirstOrDefault(i => i.IdProduct == newItem.ProductId);
            var existingItem = _Context.CartDetails.FirstOrDefault(c => c.ProductId == productId && c.UserId == UserId);
            if (existingItem != null)
            {
                existingItem.Quantity += 1;
                 //return RedirectToAction("Privacy", "Home");
            }
            else
            {
                var newItem = new CartDetail { UserId = UserId, ProductName = product.ProductName, Id = rnd.Next(0, 1000000000), ProductId = product.IdProduct, Price = product.ProductPrice, Quantity = count };
                 _Context.CartDetails.Add(newItem);
            }
            _Context.SaveChanges();
            //Перенаправление на глав страницу
            return RedirectToAction("Products", "Home");
            



        }
        [Authorize]
        public IActionResult RemoveFromCart(int itemId)
        {
            var item = _Context.CartDetails.FirstOrDefault(i => i.ProductId == itemId);
            if (item != null)
            {
                item.Quantity -= 1;

                if(item.Quantity == 0)
                {
                    _Context.CartDetails.Remove(item);
                    _Context.SaveChanges();
                }
            }
            //else if (item.Quantity == 0)
            //{
            //    _Context.CartDetails.Remove(item);
            //    _Context.SaveChanges();
            //}
            _Context.SaveChanges();
            //Перенаправление на глав страницу
            return RedirectToAction("Cart", "Cart");
        }
        [Authorize]
        public IActionResult CreateOrder(int UserId)
        {
            Random rnd = new Random();
            var DateNow = DateTime.UtcNow;
           
           
           

            var usersss = User.Identity.Name;
            var uss = _Context.Users.FirstOrDefault(u => u.UserName == usersss);
            UserId = uss.IdUsers;

            var Cartl = _Context.CartDetails.Where(cd => cd.UserId == UserId).ToList();

            decimal TotalAmount = 0;
            int constraints = Cartl.Count;


            foreach (var prop in Cartl)
            {
                var property = _Context.Products.FirstOrDefault(prope => prope.IdProduct == prop.ProductId);
                if (property.ProductCount == 0)
                {
                    TempData["eRmessage"] = "товара нет в наличии: " + property.ProductName;
                    return RedirectToAction("PersonalCabinet", "Account");
                }
                
            }

            for (int i = 0; constraints > 0; i++)
            {
                if (Cartl[i].Quantity >0)
                {
                    TotalAmount += Cartl[i].Price * Cartl[i].Quantity;
                }
                
                else
                {
                    return RedirectToAction("Cart", "Cart");
                }

                //var price = Cartl[i].Price;
                //TotalAmount += price;

                constraints--;

            }       
            var Item = new UserOrder
            {
                UserOrderId = rnd.Next(0, 1000000000),
                CreatTime = DateNow,
                IsDeleted = false,
                UserId = UserId,
                TotalPrice = TotalAmount,
                StatusId = 0
            };
            
            
            return View(new OrderViewModel { UserOrders = new List<UserOrder> { Item}, CartDetails =Cartl }) ;
        }
        [Authorize]
        public IActionResult AddToDataBaseOrder(int UserId,int itemId) 
        {

            Random rnd = new Random();
            var DateNow = DateTime.UtcNow;
            



            var usersss = User.Identity.Name;
            var uss = _Context.Users.FirstOrDefault(u => u.UserName == usersss);
            UserId = uss.IdUsers;

            var Cartl = _Context.CartDetails.Where(cd => cd.UserId == UserId).ToList();


            foreach (var prop in Cartl)
            {
                var property = _Context.Products.FirstOrDefault(prope => prope.IdProduct == prop.ProductId);
                if (property.ProductCount == 0)
                {
                    TempData["eRmessage"] = "товара нет в наличии: " + property.ProductName;
                    return RedirectToAction("PersonalCabinet", "Account");
                }
                property.ProductCount -= 1;
            }

            //while (Cartl.Count != null)
            //{
            //    var prop = _Context.CartDetails.FirstOrDefault(p => p.UserId == UserId);
            //    while (prop != null)
            //    {
            //        var property = _Context.Products.FirstOrDefault(prope => prope.IdProduct == prop.ProductId);
            //        if (property.ProductCount == 0)
            //        {
            //            TempData["eRmessage"] = "товара нет в наличии: " + property.ProductName;
            //            return RedirectToAction("PersonalCabinet", "Account");
            //        }
            //        property.ProductCount -= 1;
            //    }

            //}



            decimal TotalAmount = 0;
            int constraints = Cartl.Count;
            int PrCount = Cartl.Count;

            //for (int i = 0; constraints > 0; i++)
            //{
            //    var price = Cartl[i].Price;
            //    TotalAmount += price;
            //    constraints--;

            //}
            for (int i = 0; constraints > 0; i++)
            {
                if (Cartl[i].Quantity > 0)
                {
                    TotalAmount += Cartl[i].Price * Cartl[i].Quantity;
                }
                else
                {
                    return RedirectToAction("Cart", "Cart");
                }
                //var price = Cartl[i].Price;
                //TotalAmount += price;
                constraints--;
            }

            var Item = new UserOrder
            {
                UserOrderId         = rnd.Next(0, 99999999),
                CreatTime           = DateNow,
                IsDeleted           = false,
                UserId              = UserId,                
                TotalPrice          = TotalAmount
            };
            int tr = 0;
            
            foreach (var item in Cartl)
            {
                var property = _Context.Products.FirstOrDefault(prope => prope.IdProduct == item.ProductId);
                if (property == null)
                {
                    TempData["eRmessage"] = "ошибка";
                    return RedirectToAction("PersonalCabinet", "Account");
                }
                var ItemOrderList = new OrderListUser {
                     IdUserOrder    = Item.UserOrderId,
                    IdOrderList    = rnd.Next(0, 9999999),
                     IdProduct      = property.IdProduct,
                     IdUser         = UserId,
                     ProductCount   = Cartl[tr].Quantity,
                     ProductName    = property.ProductName,
                     ProductPrice   = property.ProductPrice,

                };
                _Context.OrderListUsers.Add(ItemOrderList);
                _Context.SaveChanges();
                tr++;
            }

            _Context.UserOrders.Add(Item);
            _Context.SaveChanges();        
            TempData["AccessMessage"] = "Заказ оформлен успешно, в течение суток администратор напишет вам на почту или позвонит на номер телефона, для обсуждения деталей заказа.";
            
            return RedirectToAction("PersonalCabinet", "Account");
        }

    }
}
