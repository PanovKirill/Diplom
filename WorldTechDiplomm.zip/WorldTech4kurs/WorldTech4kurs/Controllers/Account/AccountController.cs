﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Elfie.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Security.Claims;
using WorldTech4kurs.Models;
using WorldTech4kurs.ViewModel;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace WorldTech4kurs.Controllers.Account
{
    public class AccountController : Controller
    {
        private readonly A0982169Diplom123Context _context;
        public string password;
        public AccountController(A0982169Diplom123Context context)
        {
            _context = context;
        }
        [Authorize]
        public IActionResult PersonalCabinet(int UserId)
        {            
            var usersss = User.Identity.Name;
            var uss = _context.Users.FirstOrDefault(u => u.UserName == usersss);
            var Userss = _context.Users.Where(us=> us.UserName == usersss).ToList();
            UserId = uss.IdUsers;
            var UserOrders = _context.UserOrders.Where(uo=> uo.UserId == UserId).ToList();
            if(UserOrders.Count == 0)
            {
                TempData["emptycart"] = "У вас нет заказов на данный момент";
            }
            
           
            return View(new PersonalCabinetViewModel { Userss = Userss, UserOrders = UserOrders });
        }
        [Authorize]
        public IActionResult AdminPanel()
        {
            var UserOrderslist = _context.UserOrders.ToList();
            var User = _context.Users.ToList();
            var matchingOrders = UserOrderslist.Where(order => User.Any(user => user.IdUsers == order.UserId)).ToList();
           
            return View(new UserOrderViewModel { UserOrders = UserOrderslist });
        }
        [Authorize]
        public IActionResult AcceptOrder(int UserOrderId)
        {
            var UserOrder = _context.UserOrders.FirstOrDefault(o=>o.UserOrderId == UserOrderId);
            //Random random = new Random();
            //var check = random.Next(3,123456789);
            //if(check == UserOrder.Id)
            //{
            //    return RedirectToAction("AdminPanel");
            //}
            if(UserOrder == null)
            {
                return RedirectToAction("AdminPanel");
            }
            UserOrder.StatusId = 1;
            //var data = new UserOrder()
            //{
            //    CreatTime   = DateTime.Now,
            //    UserOrderId = UserOrder.UserOrderId,
            //    IsDeleted   = false,
            //    StatusId    = 1,
            //    TotalPrice  = UserOrder.TotalPrice,
            //    UserId      = UserOrder.UserId
                
            //};
            //_context.UserOrders.Add(data);
            _context.SaveChanges();
            TempData["successAcceptMessage"] = "Подтверждение произошло успешно";
            return RedirectToAction("AdminPanel");
        }
        [Authorize]
        public IActionResult FinishOrder(int UserOrderId)
        {
            var UserOrder = _context.UserOrders.FirstOrDefault(o=>o.UserOrderId == UserOrderId);
            //Random random = new Random();
            //var check = random.Next(3,123456789);
            //if(check == UserOrder.Id)
            //{
            //    return RedirectToAction("AdminPanel");
            //}
            if(UserOrder == null)
            {
                return RedirectToAction("AdminPanel");
            }
            UserOrder.StatusId = 2;
            //var data = new UserOrder()
            //{
            //    CreatTime   = DateTime.Now,
            //    UserOrderId = UserOrder.UserOrderId,
            //    IsDeleted   = false,
            //    StatusId    = 1,
            //    TotalPrice  = UserOrder.TotalPrice,
            //    UserId      = UserOrder.UserId
                
            //};
            //_context.UserOrders.Add(data);
            _context.SaveChanges();
            TempData["successAcceptMessage"] = "Подтверждение произошло успешно";
            return RedirectToAction("AdminPanel");
        }

        [Authorize]
        public IActionResult ViewListOrder(int UserOrderId)
        {
            var test = 0;
            var UserListOrder = _context.OrderListUsers.Where(u => u.IdUserOrder == UserOrderId).ToList();
            if (UserListOrder.Count == 0)
            {
                return RedirectToAction("PersonalCabinet");
            }
            var allListOrder = new List<OrderListUser>();
            var allListOrderTEST = new List<OrderListUser>();
            allListOrderTEST.Clear();
            var perCount = 0;
            foreach(var item in UserListOrder)
            {
               
               
                
                if(perCount != UserListOrder.Count)
                {
                    allListOrder.AddRange(_context.OrderListUsers.Where(_u => _u.IdUserOrder == item.IdUserOrder).Distinct());
                    allListOrderTEST.AddRange(allListOrder);
                    allListOrder.Clear();
                    return View(new ViewListOrderViewModel { listUsers = allListOrderTEST });
                }
            }
            return View(); 
        }


        [Authorize]
        public IActionResult DeleteOrder(int UserOrderId)
        {
            var matchingOrders = _context.OrderListUsers.Where(u => u.IdUserOrder == UserOrderId);
            _context.RemoveRange(matchingOrders);
            _context.SaveChanges();

            var UserOrder = _context.UserOrders.FirstOrDefault(o => o.UserOrderId == UserOrderId);
            if (UserOrder == null)
            {
                return RedirectToAction("AdminPanel");
            }
            UserOrder.IsDeleted = true;
            _context.UserOrders.Remove(UserOrder);
            ;
            _context.SaveChanges();
            TempData["successAcceptMessage"] = "Подтверждение произошло успешно";
            return RedirectToAction("AdminPanel");
        }
        [Authorize]
        public IActionResult DetailsOrderUser(int UserId)
        {
            var User = _context.Users.Where(u=>u.IdUsers == UserId).ToList(); 
            
            return View(new PersonalCabinetViewModel { Userss = User} );
        }
        [Authorize]
        public IActionResult ComfirmOrder(int UserOrderId)
        {
            var UserOrder = _context.UserOrders.FirstOrDefault(o=>o.UserOrderId == UserOrderId);
            //Random random = new Random();
            //var check = random.Next(3,123456789);
            //if(check == UserOrder.Id)
            //{
            //    return RedirectToAction("AdminPanel");
            //}
            if(UserOrder == null)
            {
                return RedirectToAction("AdminPanel");
            }
            UserOrder.StatusId = 0;
            //var data = new UserOrder()
            //{
            //    CreatTime   = DateTime.Now,
            //    UserOrderId = UserOrder.UserOrderId,
            //    IsDeleted   = false,
            //    StatusId    = 1,
            //    TotalPrice  = UserOrder.TotalPrice,
            //    UserId      = UserOrder.UserId
                
            //};
            //_context.UserOrders.Add(data);
            _context.SaveChanges();
            TempData["successAcceptMessage"] = "Подтверждение произошло успешно";
            return RedirectToAction("AdminPanel");
        }


        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(LoginSingUpViewModel model, string password)
        {
            var data = _context.Users.Where(e => e.UserName == model.UserName).SingleOrDefault();
            password = model.UserPassword;

            if (data == null && password == null)
            {
                TempData["errorMessage"] = "Ошибка авторизации, логин или пароль не совпадают";
                return View(model);
            }
            else
            {
                if (ModelState.IsValid)
                {
                    return View(model);
                }
                else
                {
                    if(data != null && password != null)
                    {
                        password = password.ToSHA256String();
                        bool isValid = (data.UserName == model.UserName && data.UserPassword == password);
                        if (!isValid)
                        {
                            TempData["errorMessage"] = "Ошибка авторизации, логин или пароль не совпадают";
                            return View(model);
                        }
                        else
                        {
                            var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.UserName) }, CookieAuthenticationDefaults.AuthenticationScheme);
                            var principal = new ClaimsPrincipal(identity);
                            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                            HttpContext.Session.SetString("UserName", model.UserName);
                            return RedirectToAction("Index", "Home");
                        }
                    }
                    else
                    {
                        TempData["errorMessage"] = "Ошибка авторизации, логин или пароль не совпадают";
                        return View(model);
                    }
                }
            }
            

            //if (ModelState.IsValid)
            //{
            //    return View();
            //}
            //else
            //{

            //    var data = _context.Users.Where(e => e.UserName == model.UserName).SingleOrDefault();
            //    //var data = _context.Users.FirstOrDefault(e=> e.UserName == model.UserName);


            //    if (data != null && password != null)
            //    {
            //        password = model.UserPassword.ToSHA256String();
            //        bool isValid = (data.UserName == model.UserName && data.UserPassword == password);
            //        if (!isValid)
            //        {
            //            TempData["errorMessage"] = "Неверный пароль";
            //            return View(model);
            //        }
            //        else
            //        {
            //            var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.UserName) }, CookieAuthenticationDefaults.AuthenticationScheme);
            //            var principal = new ClaimsPrincipal(identity);
            //            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
            //            HttpContext.Session.SetString("UserName", model.UserName);
            //            return RedirectToAction("Index", "Home");
            //        }
            //    }
            //    else
            //    {
            //        TempData["errorMessage"] = "Имя пользователя или пароль не найдено";
            //        return View(model);
            //    }
            //}

        }
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var storedCookies = Request.Cookies.Keys;
            foreach (var cookies in storedCookies)
            {
                Response.Cookies.Delete(cookies);
            }
            return RedirectToAction("Index","Home");
        }
        public IActionResult SingUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SingUp(LoginSingUpViewModel model)
        {
            
            var data1 = _context.Users.Where(e => e.UserName == model.UserName).SingleOrDefault();
            if (data1 == null)
            {

                var phonenumber = model.UserPhone;
                var finalphone = phonenumber.Replace(" ", "");
                var numbernine = phonenumber.Trim();
                var test = numbernine.All(char.IsDigit);

                Random random = new Random();
                int randomId = random.Next(3, 12345678);
                if (ModelState.IsValid)
                {
                    TempData["errorMessage"] = "Пустая форма";
                    return View(model);
                }
                else if(model.UserPassword != model.ConfirmPassword)
                {
                    TempData["errorMessage"] = "Пароли не совпадают";
                    return View(model);
                }
                else if(model.UserPassword == null)
                {
                    TempData["errorMessage"] = "Пароль не может быть пустым";
                    return View(model);
                }
                else if(model.ConfirmPassword == null)
                {
                    TempData["errorMessage"] = "поле подтверждение пароля не может быть пустым";
                    return View(model);
                }
                else if(model.UserEmail == null)
                {
                    TempData["errorMessage"] = "Поле UserEmail не должно быть пустым";
                    return View(model);
                }
                else if(model.UserName == null)
                {
                    TempData["errorMessage"] = "Имя не может быть пустым";
                    return View(model);
                }
                else if(model.UserPhone == null)
                {
                    TempData["errorMessage"] = "Телефон не может быть пустым";
                    return View(model);
                }
                else if(finalphone.Length < 11)
                {
                    TempData["errorMessage"] = "поле с номером телефона содержит ошибку";
                    return View(model);
                }
                else if (test == false)
                {
                    TempData["errorMessage"] = "В телефоне не должно быть букв";
                    return View(model);
                }
                else
                {
                    var data = new User()
                    {
                        UserName = model.UserName,
                        UserEmail = model.UserEmail,
                        UserPassword = model.UserPassword.ToSHA256String(),
                        IdRoles = 2,
                        IdUsers = randomId,
                        UserPhone = model.UserPhone,

                    };
                    _context.Users.Add(data);
                    _context.SaveChanges();
                    TempData["successMessage"] = "Регистрация прошла успешно, заполните все поля";
                    return RedirectToAction("Login");
                }
            }
            else
            {
                TempData["errorMessage"] = "такой UserName уже существует";
                return View(model);
            }
            
        }

    }
}
